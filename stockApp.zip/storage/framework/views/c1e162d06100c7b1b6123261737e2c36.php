<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Products</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>

<body>
    <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1>Edit Product</h1>
    <form action="<?php echo e(route('products.update', $product)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="mb-3">
            <label for="kodeBarang" class="form-label">Kode Barang</label>
            <input type="text" class="form-control" id="kodeBarang" name="kodeBarang"
                value="<?php echo e($product->kodeBarang); ?>" readonly>
        </div>
        <div class="mb-3">
            <label for="namaProduct" class="form-label">Nama Product</label>
            <input type="text" class="form-control" id="namaProduct" name="namaProduct"
                value="<?php echo e($product->namaProduct); ?>" required>
        </div>
        <div class="mb-3">
            <label for="quantity" class="form-label">Quantity</label>
            <input type="number" class="form-control" id="quantity" name="quantity" value="<?php echo e($product->quantity); ?>"
                required>
        </div>
        <div class="mb-3">
            <label for="harga" class="form-label">Harga</label>
            <input type="number" class="form-control" id="harga" name="harga" step="0.01"
                value="<?php echo e($product->harga); ?>" required>
        </div>
        <button type="submit" class="btn btn-primary">Update Product</button>
    </form>
</body>

</html>
<?php /**PATH C:\My Project\Laravel Project\stockApp\resources\views/products/edit.blade.php ENDPATH**/ ?>